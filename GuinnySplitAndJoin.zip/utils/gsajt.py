import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os
from pathlib import Path
import re
from collections import defaultdict

class FileSplitterJoinerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Guinness's File Split and Join Tool")
        self.directory = ''  
        self.setup_ui()
        self.load_theme()

    def setup_ui(self):
        self.main_frame = ttk.Frame(self)
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        self.tabs = ttk.Notebook(self.main_frame)
        self.tabs.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)

        self.split_tab = ttk.Frame(self.tabs)
        self.tabs.add(self.split_tab, text="Split File")

        self.join_tab = ttk.Frame(self.tabs)
        self.tabs.add(self.join_tab, text="Join Files")

        self.build_split_ui()
        self.build_join_ui()

    def load_theme(self):
        self.style = ttk.Style(self)
        self.style.theme_use("clam")

        self.style.configure("TFrame", background="#333333")
        self.style.configure("TNotebook", background="#333333", foreground="#D9D9D9")
        self.style.configure("TNotebook.Tab", background="#2D2D2D", foreground="#D9D9D9")
        self.style.configure("TButton", background="#4D4D4D", foreground="#FFFFFF")

    def build_split_ui(self):
        self.file_label = ttk.Label(self.split_tab, text="File to split:")
        self.file_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")
        self.file_entry = ttk.Entry(self.split_tab)
        self.file_entry.grid(row=0, column=1, padx=10, pady=5, sticky="ew")
        self.browse_button = ttk.Button(self.split_tab, text="Browse", command=self.browse_file)
        self.browse_button.grid(row=0, column=2, padx=10, pady=5)

        self.size_label = ttk.Label(self.split_tab, text="Size per file (MB):")
        self.size_label.grid(row=1, column=0, padx=10, pady=5, sticky="w")
        self.size_entry = ttk.Entry(self.split_tab)
        self.size_entry.grid(row=1, column=1, padx=10, pady=5, sticky="ew")

        self.split_button = ttk.Button(self.split_tab, text="Split File", command=self.split_file)
        self.split_button.grid(row=2, column=0, columnspan=3, padx=10, pady=10)

    def build_join_ui(self):
        self.base_file_label = ttk.Label(self.join_tab, text="Base filename:")
        self.base_file_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")
        self.base_file_entry = ttk.Entry(self.join_tab)
        self.base_file_entry.grid(row=0, column=1, padx=10, pady=5, sticky="ew")
        
        self.browse_base_button = ttk.Button(self.join_tab, text="Browse", command=self.browse_base_file)
        self.browse_base_button.grid(row=0, column=2, padx=10, pady=5)

        self.detected_files_label = ttk.Label(self.join_tab, text="Detected split files:")
        self.detected_files_label.grid(row=1, column=0, padx=10, pady=5, sticky="w")
        self.detected_files_combobox = ttk.Combobox(self.join_tab)
        self.detected_files_combobox.grid(row=1, column=1, padx=10, pady=5, sticky="ew", columnspan=2)

        self.join_button = ttk.Button(self.join_tab, text="Join Files", command=self.join_files)
        self.join_button.grid(row=2, column=0, columnspan=3, padx=10, pady=10)

    def browse_file(self):
        file_path = filedialog.askopenfilename()
        if file_path:
            self.file_entry.delete(0, tk.END)
            self.file_entry.insert(0, file_path)

    def browse_base_file(self):
        self.directory = filedialog.askdirectory()
        if self.directory:
            self.base_file_entry.delete(0, tk.END)
            self.base_file_entry.insert(0, self.directory)
            self.detect_split_files(self.directory)

    def split_file(self):
        filename = self.file_entry.get()
        size = self.size_entry.get()
        if not filename or not size.isdigit():
            messagebox.showerror("Error", "Please provide a valid file and size.")
            return
        try:
            size = int(size) * 1024 * 1024
            part_num = 0
            with open(filename, 'rb') as src:
                chunk = src.read(size)
                while chunk:
                    part_num += 1
                    with open(f"{filename}.part{part_num}", 'wb') as dst:
                        dst.write(chunk)
                    chunk = src.read(size)
            messagebox.showinfo("Success", f"File split into {part_num} parts.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to split file: {str(e)}")

    def detect_split_files(self, directory):
        print(f"Scanning directory: {directory}")
        files = defaultdict(list)
        for file in Path(directory).glob('*.part*'):
            print(f"Found file: {file}")
            base_name = re.match(r"(.+)\.part\d+", file.name)
            if base_name:
                files[base_name.group(1)].append(file.name)
        detected_bases = list(files.keys())
        if detected_bases:
            self.detected_files_combobox['values'] = detected_bases
            self.detected_files_combobox.current(0)
        else:
            self.detected_files_combobox['values'] = []
            messagebox.showinfo("Info", "No split files detected in the selected directory.")

    def join_files(self):
        base_filename = self.base_file_entry.get()
        if not base_filename:
            messagebox.showerror("Error", "Please provide a base filename.")
            return
        try:
            files = sorted(Path(self.directory).glob(f'{Path(base_filename).name}.part*'), key=lambda x: int(x.suffix.split('part')[-1]))
            with open(f"{base_filename}_joined", 'wb') as dst:
                for file in files:
                    with open(file, 'rb') as src:
                        data = src.read()
                        dst.write(data)
            messagebox.showinfo("Success", "Files have been successfully joined.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to join files: {str(e)}")

if __name__ == "__main__":
    app = FileSplitterJoinerApp()
    app.mainloop()
